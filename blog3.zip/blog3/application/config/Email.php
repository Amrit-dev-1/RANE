<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
    'protocol' => 'smtp',
    'smtp_host' => 'smtp.gmail.com', // Replace with your SMTP host
    'smtp_port' => '587', // Replace with your SMTP port
    'smtp_user' => 'webdeveloper1.crezvatic@gmail.com', // Replace with your SMTP username
    'smtp_pass' => 'uzow tuoo ddke dypp', // Replace with your SMTP password
    'mailtype' => 'html',
    'charset' => 'utf-8',
    'newline' => "\r\n"
);

return $config;


// uzow tuoo ddke dypp