
<head>
    <link rel="stylesheet" href="assets/css/client.css">
</head>
<style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .client {
            margin: auto;
            flex-wrap: wrap;
            justify-content: center;
            padding: 0 10px; /* Adjust as needed */
        }

     

        

        .client-logo:hover {
            transform: scale(1.2);
        }
    </style>



<div class="client">
    <div class="row">
        <div class="col-md-2">
        <img src="<?php base_url(); ?>assets/image/Client/Color/Cidco Color Logo-01.png" alt="logo1" class="client-logo" >
        </div>
        <div class="col-md-2">
        <img src="<?php base_url(); ?>assets/image/Client/Color/DFC Logo Color-01.png" alt="logo1" class="client-logo" >
        </div>
        <div class="col-md-2">
        <img src="<?php base_url(); ?>assets/image/Client/Color/Suez Color Logo-01.png" alt="logo1" class="client-logo" >
        </div>
        <div class="col-md-2">
        <img src="<?php base_url(); ?>assets/image/Client/Color/MMRD Logo Color-01.png" alt="logo1" class="client-logo" >
        </div>
    </div>

    <div class="row">
        <div class="col-md-2">
        <img src="<?php base_url(); ?>assets/image/Client/Color/Reliance Color Logo-01.png" alt="logo1" class="client-logo" >
        </div>
        <div class="col-md-2">
        <img src="<?php base_url(); ?>assets/image/Client/Color/RNVL Color Logo-01.png" alt="logo1" class="client-logo" >
        </div>
        <div class="col-md-2">
        <img src="<?php base_url(); ?>assets/image/Client/Color/NHAI Color Logo-01.png" alt="logo1" class="client-logo" >
        </div>
        <div class="col-md-2">
        <img src="<?php base_url(); ?>assets/image/Client/Color/MSRDC Color Logo-01.png" alt="logo1" class="client-logo" >
        </div>
    </div>
</div>