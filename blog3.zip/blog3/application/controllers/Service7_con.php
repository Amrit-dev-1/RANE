<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service7_con extends CI_Controller {

	
	public function index()
	{
		$this->load->view('RMC_view/service7_view.php');
	}
}
