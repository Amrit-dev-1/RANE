<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Text_con extends CI_Controller {

	
	public function index()
	{
		$this->load->view('RMC_view/index2.php');
	}
}
