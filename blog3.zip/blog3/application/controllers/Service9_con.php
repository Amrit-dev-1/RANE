<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service9_con extends CI_Controller {

	
	public function index()
	{
		$this->load->view('RMC_view/service9_view.php');
	}
}
