<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service2_con extends CI_Controller {

	
	public function index()
	{
		$this->load->view('RMC_view/service2_view.php');
	}
}
